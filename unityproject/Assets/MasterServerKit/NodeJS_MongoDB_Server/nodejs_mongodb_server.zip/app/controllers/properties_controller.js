// Copyright (C) 2016 Spelltwine Games. All rights reserved.
// This code can only be used under the standard Unity Asset Store End User License Agreement,
// a copy of which is available at http://unity3d.com/company/legal/as_terms.

'use strict';

var mongoose = require('mongoose');
var passport = require('passport');
var User = mongoose.model('User');

var sendJSONResponse = function (res, status, content) {
    res.status(status);
    res.json(content);
};

module.exports.getIntProperty = function (req, res) {
    // Check all the required fields are present.
    if (!req.query.username || !req.query.key) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'All fields are required.'
        });
        return;
    }

    User.findOne({ username: req.query.username }, function (err, user) {
        if (user != null) {
            if (req.query.key in user.intProperties) {
                sendJSONResponse(res, 200, {
                    'status': 'success',
                    'value': user.intProperties[req.query.key]
                });
            } else {
                sendJSONResponse(res, 401, {
                    'status': 'error',
                    'message': 'This property does not exist.'
                });
            }
        } else {
            sendJSONResponse(res, 401, {
                'status': 'error',
                'message': 'This user does not exist.'
            });
        }
    });
};

module.exports.setIntProperty = function (req, res) {
    // Check all the required fields are present.
    if (!req.body.username || !req.body.key || !req.body.value) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'All fields are required.'
        });
        return;
    }

    User.findOne({ username: req.body.username }, function (err, user) {
        if (user != null) {
            user.intProperties[req.body.key] = req.body.value;
            user.markModified('intProperties');
            user.save(function (err) {
                if (err) {
                    sendJSONResponse(res, 404, {
                        'status': 'error',
                        'message': 'Server error.'
                    });
                    return;
                } else {
                    sendJSONResponse(res, 200, {
                        'status': 'success',
                        'value': user.intProperties[req.body.key]
                    });
                }
            });
        } else {
            sendJSONResponse(res, 401, {
                'status': 'error',
                'message': 'This user does not exist.'
            });
        }
    });
};

module.exports.getStringProperty = function (req, res) {
    // Check all the required fields are present.
    if (!req.query.username || !req.query.key) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'All fields are required.'
        });
        return;
    }

    User.findOne({ username: req.query.username }, function (err, user) {
        if (user != null) {
            if (req.query.key in user.stringProperties) {
                sendJSONResponse(res, 200, {
                    'status': 'success',
                    'value': user.stringProperties[req.query.key]
                });
            } else {
                sendJSONResponse(res, 401, {
                    'status': 'error',
                    'message': 'This property does not exist.'
                });
            }
        } else {
            sendJSONResponse(res, 401, {
                'status': 'error',
                'message': 'This user does not exist.'
            });
        }
    });
};

module.exports.setStringProperty = function (req, res) {
    // Check all the required fields are present.
    if (!req.body.username || !req.body.key || !req.body.value) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'All fields are required.'
        });
        return;
    }

    User.findOne({ username: req.body.username }, function (err, user) {
        if (user != null) {
            user.stringProperties[req.body.key] = req.body.value;
            user.markModified('stringProperties');
            user.save(function (err) {
                if (err) {
                    sendJSONResponse(res, 404, {
                        'status': 'error',
                        'message': 'Server error.'
                    });
                    return;
                } else {
                    sendJSONResponse(res, 200, {
                        'status': 'success',
                        'value': user.stringProperties[req.body.key]
                    });
                }
            });
        } else {
            sendJSONResponse(res, 401, {
                'status': 'error',
                'message': 'This user does not exist.'
            });
        }
    });
};