// Copyright (C) 2016 Spelltwine Games. All rights reserved.
// This code can only be used under the standard Unity Asset Store End User License Agreement,
// a copy of which is available at http://unity3d.com/company/legal/as_terms.

'use strict';

var mongoose = require('mongoose');
var passport = require('passport');
var User = mongoose.model('User');

var sendJSONResponse = function (res, status, content) {
    res.status(status);
    res.json(content);
};

module.exports.register = function (req, res) {
    // Check if all the required fields are present.
    if (!req.body.email){
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'An email address is required.',
            'error': 1
        });
        return;
    }

    if (!req.body.username) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'An username is required.',
            'error': 2
        });
        return;
    }

    if (!req.body.password) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'A password is required.',
            'error': 3
        });
        return;
    }

    // Check if a user with the same email already exists.
    User.findOne({ email: req.body.email }, function (err, user) {
        if (user != null) {
            sendJSONResponse(res, 400, {
                'status': 'error',
                'message': 'This email is already registered.',
                'error': 4
            });
            return;
        }
        else {
            // Check if a user with the same name already exists.
            User.findOne({ username: req.body.username }, function (err, user) {
                if (user != null) {
                    sendJSONResponse(res, 400, {
                        'status': 'error',
                        'message': 'This username is already registered.',
                        'error': 5
                    });
                    return;
                } else {
                    // Create a new user.
                    var user = new User();
                    user.email = req.body.email;
                    user.username = req.body.username;
                    user.setPassword(req.body.password);
                    user.isLoggedIn = 0;

                    // Save the new user to the database.
                    user.save(function (err) {
                        var token;
                        if (err) {
                            sendJSONResponse(res, 404, {
                                'status': 'error',
                                'message': 'Server error.',
                                'error': 0
                            });
                            return;
                        } else {
                            token = user.generateJWT();
                            sendJSONResponse(res, 200, {
                                'status': 'success',
                                'token': token
                            });
                        }
                    });
                }
            });
        }
    });
};

module.exports.login = function (req, res) {
    // Check all the required fields are present.
    if (!req.body.username) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'An username is required.',
            'error': 1
        });
        return;
    }

    if (!req.body.password) {
        sendJSONResponse(res, 400, {
            'status': 'error',
            'message': 'A password is required.',
            'error': 2
        });
        return;
    }

    // Authenticate the user via Passport.
    passport.authenticate('local', function (err, user, info) {
        var token;

        if (err) {
            sendJSONResponse(res, 404, {
                'status': 'error',
                'message': 'Server error.',
                'error': 0
            });
            return;
        }

        if (user) {
            token = user.generateJWT();
            sendJSONResponse(res, 200, {
                'status': 'success',
                'token': token,
                'username': user.username
            });
        } else {
            sendJSONResponse(res, 401, {
                'status': 'error',
                'message': 'Invalid credentials.',
                'error': 4
            });
        }
    })(req, res);
};